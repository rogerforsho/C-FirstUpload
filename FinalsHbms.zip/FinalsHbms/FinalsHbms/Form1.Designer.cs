﻿namespace FinalsHbms
{
    partial class Home
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            Logo = new PictureBox();
            Navbarpanel = new Panel();
            Signupbtn = new Button();
            Hotelpicpanel = new Panel();
            pictureBox1 = new PictureBox();
            LoginHolderPanel = new Panel();
            label8 = new Label();
            AboutUs = new Label();
            button1 = new Button();
            label7 = new Label();
            label6 = new Label();
            PasswordUserTxt = new Guna.UI2.WinForms.Guna2TextBox();
            label5 = new Label();
            LoginUserTxt = new Guna.UI2.WinForms.Guna2TextBox();
            TextHolderPanel = new Panel();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            label3 = new Label();
            LoginPanel = new Panel();
            label4 = new Label();
            guna2AnimateWindow1 = new Guna.UI2.WinForms.Guna2AnimateWindow(components);
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Logo).BeginInit();
            Navbarpanel.SuspendLayout();
            Hotelpicpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            LoginHolderPanel.SuspendLayout();
            TextHolderPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            LoginPanel.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(Logo);
            panel1.Location = new Point(36, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(141, 139);
            panel1.TabIndex = 0;
            // 
            // Logo
            // 
            Logo.Dock = DockStyle.Fill;
            Logo.Image = (Image)resources.GetObject("Logo.Image");
            Logo.Location = new Point(0, 0);
            Logo.Name = "Logo";
            Logo.Size = new Size(141, 139);
            Logo.SizeMode = PictureBoxSizeMode.StretchImage;
            Logo.TabIndex = 2;
            Logo.TabStop = false;
            // 
            // Navbarpanel
            // 
            Navbarpanel.BorderStyle = BorderStyle.FixedSingle;
            Navbarpanel.Controls.Add(Signupbtn);
            Navbarpanel.Dock = DockStyle.Top;
            Navbarpanel.Location = new Point(0, 0);
            Navbarpanel.Name = "Navbarpanel";
            Navbarpanel.Size = new Size(911, 78);
            Navbarpanel.TabIndex = 1;
            // 
            // Signupbtn
            // 
            Signupbtn.BackColor = Color.Transparent;
            Signupbtn.FlatAppearance.BorderSize = 0;
            Signupbtn.FlatStyle = FlatStyle.Flat;
            Signupbtn.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Signupbtn.ForeColor = Color.Black;
            Signupbtn.Location = new Point(826, 11);
            Signupbtn.Name = "Signupbtn";
            Signupbtn.Size = new Size(72, 57);
            Signupbtn.TabIndex = 3;
            Signupbtn.Text = "Sign up";
            Signupbtn.UseVisualStyleBackColor = false;
            Signupbtn.Click += Signupbtn_Click;
            // 
            // Hotelpicpanel
            // 
            Hotelpicpanel.Controls.Add(pictureBox1);
            Hotelpicpanel.Location = new Point(12, 145);
            Hotelpicpanel.Name = "Hotelpicpanel";
            Hotelpicpanel.Size = new Size(521, 313);
            Hotelpicpanel.TabIndex = 2;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(521, 313);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // LoginHolderPanel
            // 
            LoginHolderPanel.BackColor = SystemColors.ControlDark;
            LoginHolderPanel.BorderStyle = BorderStyle.FixedSingle;
            LoginHolderPanel.Controls.Add(label8);
            LoginHolderPanel.Controls.Add(AboutUs);
            LoginHolderPanel.Controls.Add(button1);
            LoginHolderPanel.Controls.Add(label7);
            LoginHolderPanel.Controls.Add(label6);
            LoginHolderPanel.Controls.Add(PasswordUserTxt);
            LoginHolderPanel.Controls.Add(label5);
            LoginHolderPanel.Controls.Add(LoginUserTxt);
            LoginHolderPanel.Location = new Point(551, 145);
            LoginHolderPanel.Name = "LoginHolderPanel";
            LoginHolderPanel.Size = new Size(348, 620);
            LoginHolderPanel.TabIndex = 3;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Georgia", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(214, 276);
            label8.Name = "label8";
            label8.Size = new Size(78, 16);
            label8.TabIndex = 12;
            label8.Text = "Contact Us!";
            label8.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // AboutUs
            // 
            AboutUs.AutoSize = true;
            AboutUs.Font = new Font("Georgia", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            AboutUs.Location = new Point(61, 276);
            AboutUs.Name = "AboutUs";
            AboutUs.Size = new Size(71, 16);
            AboutUs.TabIndex = 11;
            AboutUs.Text = "About Us?";
            AboutUs.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // button1
            // 
            button1.BackColor = Color.DodgerBlue;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ActiveCaptionText;
            button1.Location = new Point(61, 225);
            button1.Name = "button1";
            button1.Size = new Size(231, 39);
            button1.TabIndex = 10;
            button1.Text = "LOGIN";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Georgia", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(114, 206);
            label7.Name = "label7";
            label7.Size = new Size(117, 16);
            label7.TabIndex = 6;
            label7.Text = "Forgot Password?";
            label7.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label6.Location = new Point(114, 122);
            label6.Name = "label6";
            label6.Size = new Size(109, 24);
            label6.TabIndex = 9;
            label6.Text = "Password";
            // 
            // PasswordUserTxt
            // 
            PasswordUserTxt.CustomizableEdges = customizableEdges5;
            PasswordUserTxt.DefaultText = "";
            PasswordUserTxt.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            PasswordUserTxt.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            PasswordUserTxt.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            PasswordUserTxt.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            PasswordUserTxt.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            PasswordUserTxt.Font = new Font("Segoe UI", 9F);
            PasswordUserTxt.ForeColor = Color.Black;
            PasswordUserTxt.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            PasswordUserTxt.Location = new Point(34, 150);
            PasswordUserTxt.Margin = new Padding(3, 4, 3, 4);
            PasswordUserTxt.Name = "PasswordUserTxt";
            PasswordUserTxt.PlaceholderText = "";
            PasswordUserTxt.SelectedText = "";
            PasswordUserTxt.ShadowDecoration.CustomizableEdges = customizableEdges6;
            PasswordUserTxt.Size = new Size(286, 43);
            PasswordUserTxt.TabIndex = 8;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label5.Location = new Point(114, 47);
            label5.Name = "label5";
            label5.Size = new Size(115, 24);
            label5.TabIndex = 7;
            label5.Text = "Username";
            // 
            // LoginUserTxt
            // 
            LoginUserTxt.CustomizableEdges = customizableEdges7;
            LoginUserTxt.DefaultText = "";
            LoginUserTxt.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            LoginUserTxt.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            LoginUserTxt.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            LoginUserTxt.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            LoginUserTxt.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            LoginUserTxt.Font = new Font("Segoe UI", 9F);
            LoginUserTxt.ForeColor = Color.Black;
            LoginUserTxt.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            LoginUserTxt.Location = new Point(34, 75);
            LoginUserTxt.Margin = new Padding(3, 4, 3, 4);
            LoginUserTxt.Name = "LoginUserTxt";
            LoginUserTxt.PlaceholderText = "";
            LoginUserTxt.SelectedText = "";
            LoginUserTxt.ShadowDecoration.CustomizableEdges = customizableEdges8;
            LoginUserTxt.Size = new Size(286, 43);
            LoginUserTxt.TabIndex = 0;
            LoginUserTxt.TextChanged += LoginUserTxt_TextChanged;
            // 
            // TextHolderPanel
            // 
            TextHolderPanel.Controls.Add(pictureBox4);
            TextHolderPanel.Controls.Add(pictureBox3);
            TextHolderPanel.Controls.Add(pictureBox2);
            TextHolderPanel.Controls.Add(label2);
            TextHolderPanel.Controls.Add(label1);
            TextHolderPanel.Location = new Point(12, 464);
            TextHolderPanel.Name = "TextHolderPanel";
            TextHolderPanel.Size = new Size(521, 313);
            TextHolderPanel.TabIndex = 3;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(372, 129);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(130, 116);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 5;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(194, 129);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(130, 116);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 4;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(24, 129);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(130, 116);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Georgia", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(15, 53);
            label2.Name = "label2";
            label2.Size = new Size(487, 64);
            label2.TabIndex = 2;
            label2.Text = resources.GetString("label2.Text");
            label2.TextAlign = ContentAlignment.MiddleLeft;
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label1.Location = new Point(81, 17);
            label1.Name = "label1";
            label1.Size = new Size(341, 24);
            label1.TabIndex = 1;
            label1.Text = "WELCOME TO LUXURY HOTEL";
            label1.Click += label1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(255, 129, 0);
            label3.Location = new Point(183, 66);
            label3.Name = "label3";
            label3.Size = new Size(188, 26);
            label3.TabIndex = 3;
            label3.Text = "LUXURY HOTEL";
            // 
            // LoginPanel
            // 
            LoginPanel.BackColor = SystemColors.ActiveCaption;
            LoginPanel.BorderStyle = BorderStyle.FixedSingle;
            LoginPanel.Controls.Add(label4);
            LoginPanel.Location = new Point(551, 145);
            LoginPanel.Name = "LoginPanel";
            LoginPanel.Size = new Size(348, 44);
            LoginPanel.TabIndex = 0;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label4.Location = new Point(129, 11);
            label4.Name = "label4";
            label4.Size = new Size(82, 24);
            label4.TabIndex = 6;
            label4.Text = "LOGIN";
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(911, 777);
            Controls.Add(LoginPanel);
            Controls.Add(label3);
            Controls.Add(TextHolderPanel);
            Controls.Add(LoginHolderPanel);
            Controls.Add(Hotelpicpanel);
            Controls.Add(panel1);
            Controls.Add(Navbarpanel);
            Name = "Home";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Home";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)Logo).EndInit();
            Navbarpanel.ResumeLayout(false);
            Hotelpicpanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            LoginHolderPanel.ResumeLayout(false);
            LoginHolderPanel.PerformLayout();
            TextHolderPanel.ResumeLayout(false);
            TextHolderPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            LoginPanel.ResumeLayout(false);
            LoginPanel.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private PictureBox Logo;
        private Panel Navbarpanel;
        private Button Signupbtn;
        private Panel Hotelpicpanel;
        private PictureBox pictureBox1;
        private Panel LoginHolderPanel;
        private Panel TextHolderPanel;
        private Label label1;
        private Label label2;
        private Label label3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private Panel LoginPanel;
        private Label label6;
        private Guna.UI2.WinForms.Guna2TextBox PasswordUserTxt;
        private Label label5;
        private Guna.UI2.WinForms.Guna2TextBox LoginUserTxt;
        private Label label4;
        private Label label7;
        private Button button1;
        private Label AboutUs;
        private Label label8;
        private Guna.UI2.WinForms.Guna2AnimateWindow guna2AnimateWindow1;
    }
}
