﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FinalsHbms.Properties;

namespace FinalsHbms
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void SlideSh4_Click(object sender, EventArgs e)
        {

        }

        private void LoginHolderPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Usernameregtxt_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void RegBtn_Click(object sender, EventArgs e)
        {

            string username = RegtxtboxUsername.Text.Trim();
            string passsword = RegtxtboxPassword.Text.Trim();
            string fullname = RegtxtboxFullname.Text.Trim();
            string email = RegtxtboxEmail.Text.Trim();
            string cpnoText = RegtextboxCpno.Text.Trim();

            if (long.TryParse(cpnoText, out long cpno))
            {
                InsertUser.InsertNewUser(username, passsword, fullname, email, cpno.ToString());


                RegtxtboxUsername.Text = "";
                RegtxtboxPassword.Text = "";
                RegtxtboxFullname.Text = "";
                RegtxtboxEmail.Text = "";
                RegtextboxCpno.Text = "";

            }
            else
            {
                MessageBox.Show("Invalid contact number. Please enter digits only.");
            }

            this.Hide();
            Home returntoHome = new Home();
            returntoHome.Show();

        }

        private void RegLoginbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home home = new Home();
            home.Show();
        }
    }
}
