﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace FinalsHbms
{

    public class InsertUser
    {
        public static class DatabaseConfiguration
        {
            public static string ConnectionString = "Server=localhost; Database=finalsapp; User=root; Password=;";
        }

        public static void InsertNewUser(string username, string password, string fullname, string email, string contact_number)
        {
            using (MySqlConnection con = new MySqlConnection(DatabaseConfiguration.ConnectionString))
            {
                try
                {
                    con.Open();
                    string insertQuery = "INSERT INTO users (username, password, fullname, email, contact_number) VALUES (@username, @password, @fullname, @email, @contact_number)";

                    using (MySqlCommand app = new MySqlCommand(insertQuery, con))
                    {
                        app.Parameters.AddWithValue("@username", username);
                        app.Parameters.AddWithValue("@password", password);
                        app.Parameters.AddWithValue("@fullname", fullname);
                        app.Parameters.AddWithValue("@email", email);
                        app.Parameters.AddWithValue("@contact_number", contact_number);

                        int affectRows = app.ExecuteNonQuery();

                        if (affectRows > 0)
                        {
                            MessageBox.Show("User inserted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Failed to insert user.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}
