﻿namespace FinalsHbms
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registration));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            label3 = new Label();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            TextHolderPanel = new Panel();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            RegPanel = new Panel();
            RegBtn = new Guna.UI2.WinForms.Guna2Button();
            RegtextboxCpno = new Guna.UI2.WinForms.Guna2TextBox();
            RegContactnumbertxt = new Label();
            RegtxtboxEmail = new Guna.UI2.WinForms.Guna2TextBox();
            Emailregtxt = new Label();
            RegtxtboxFullname = new Guna.UI2.WinForms.Guna2TextBox();
            Fullnameregtxt = new Label();
            RegtxtboxPassword = new Guna.UI2.WinForms.Guna2TextBox();
            RegtxtboxUsername = new Guna.UI2.WinForms.Guna2TextBox();
            Passwordregtxt = new Label();
            Usernameregtxt = new Label();
            pictureBox1 = new PictureBox();
            Hotelpicpanel = new Panel();
            Navbarpanel = new Panel();
            RegLoginbtn = new Button();
            Logo = new PictureBox();
            panel1 = new Panel();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            TextHolderPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            RegPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            Hotelpicpanel.SuspendLayout();
            Navbarpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Logo).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(255, 129, 0);
            label3.Location = new Point(183, 66);
            label3.Name = "label3";
            label3.Size = new Size(188, 26);
            label3.TabIndex = 8;
            label3.Text = "LUXURY HOTEL";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(141, 129);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(103, 104);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 4;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(15, 129);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(103, 104);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Georgia", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(68, 53);
            label2.Name = "label2";
            label2.Size = new Size(343, 48);
            label2.TabIndex = 2;
            label2.Text = "We welcome you with a beautiful lobby with exciting\r\nplaces to explore at our luxury hotel with a high rating\r\nand approval to our guest.";
            label2.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label1.Location = new Point(81, 17);
            label1.Name = "label1";
            label1.Size = new Size(299, 24);
            label1.TabIndex = 1;
            label1.Text = "TOP NOTCH 5 STAR HOTEL";
            // 
            // TextHolderPanel
            // 
            TextHolderPanel.Controls.Add(pictureBox6);
            TextHolderPanel.Controls.Add(pictureBox5);
            TextHolderPanel.Controls.Add(pictureBox3);
            TextHolderPanel.Controls.Add(pictureBox2);
            TextHolderPanel.Controls.Add(label2);
            TextHolderPanel.Controls.Add(label1);
            TextHolderPanel.Location = new Point(12, 464);
            TextHolderPanel.Name = "TextHolderPanel";
            TextHolderPanel.Size = new Size(521, 313);
            TextHolderPanel.TabIndex = 9;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(396, 129);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(106, 104);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 7;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(268, 129);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(103, 104);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 6;
            pictureBox5.TabStop = false;
            // 
            // RegPanel
            // 
            RegPanel.BackColor = SystemColors.ControlDark;
            RegPanel.BorderStyle = BorderStyle.FixedSingle;
            RegPanel.Controls.Add(RegBtn);
            RegPanel.Controls.Add(RegtextboxCpno);
            RegPanel.Controls.Add(RegContactnumbertxt);
            RegPanel.Controls.Add(RegtxtboxEmail);
            RegPanel.Controls.Add(Emailregtxt);
            RegPanel.Controls.Add(RegtxtboxFullname);
            RegPanel.Controls.Add(Fullnameregtxt);
            RegPanel.Controls.Add(RegtxtboxPassword);
            RegPanel.Controls.Add(RegtxtboxUsername);
            RegPanel.Controls.Add(Passwordregtxt);
            RegPanel.Controls.Add(Usernameregtxt);
            RegPanel.Location = new Point(551, 145);
            RegPanel.Name = "RegPanel";
            RegPanel.Size = new Size(348, 620);
            RegPanel.TabIndex = 10;
            RegPanel.Paint += LoginHolderPanel_Paint;
            // 
            // RegBtn
            // 
            RegBtn.CustomizableEdges = customizableEdges1;
            RegBtn.DisabledState.BorderColor = Color.DarkGray;
            RegBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            RegBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            RegBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            RegBtn.FillColor = SystemColors.Control;
            RegBtn.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RegBtn.ForeColor = Color.Black;
            RegBtn.Location = new Point(93, 348);
            RegBtn.Name = "RegBtn";
            RegBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            RegBtn.Size = new Size(149, 40);
            RegBtn.TabIndex = 19;
            RegBtn.Text = "Register";
            RegBtn.Click += RegBtn_Click;
            // 
            // RegtextboxCpno
            // 
            RegtextboxCpno.BorderRadius = 5;
            RegtextboxCpno.CustomizableEdges = customizableEdges3;
            RegtextboxCpno.DefaultText = "";
            RegtextboxCpno.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            RegtextboxCpno.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            RegtextboxCpno.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            RegtextboxCpno.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            RegtextboxCpno.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            RegtextboxCpno.Font = new Font("Segoe UI", 9F);
            RegtextboxCpno.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            RegtextboxCpno.Location = new Point(24, 299);
            RegtextboxCpno.Margin = new Padding(3, 4, 3, 4);
            RegtextboxCpno.Name = "RegtextboxCpno";
            RegtextboxCpno.PlaceholderText = "";
            RegtextboxCpno.SelectedText = "";
            RegtextboxCpno.ShadowDecoration.CustomizableEdges = customizableEdges4;
            RegtextboxCpno.Size = new Size(286, 31);
            RegtextboxCpno.TabIndex = 18;
            // 
            // RegContactnumbertxt
            // 
            RegContactnumbertxt.AutoSize = true;
            RegContactnumbertxt.BackColor = Color.Transparent;
            RegContactnumbertxt.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RegContactnumbertxt.ForeColor = Color.FromArgb(34, 12, 12, 1);
            RegContactnumbertxt.Location = new Point(93, 272);
            RegContactnumbertxt.Name = "RegContactnumbertxt";
            RegContactnumbertxt.Size = new Size(149, 23);
            RegContactnumbertxt.TabIndex = 17;
            RegContactnumbertxt.Text = "Contact Number";
            // 
            // RegtxtboxEmail
            // 
            RegtxtboxEmail.BorderRadius = 5;
            RegtxtboxEmail.CustomizableEdges = customizableEdges5;
            RegtxtboxEmail.DefaultText = "";
            RegtxtboxEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            RegtxtboxEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            RegtxtboxEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            RegtxtboxEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            RegtxtboxEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            RegtxtboxEmail.Font = new Font("Segoe UI", 9F);
            RegtxtboxEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            RegtxtboxEmail.Location = new Point(24, 232);
            RegtxtboxEmail.Margin = new Padding(3, 4, 3, 4);
            RegtxtboxEmail.Name = "RegtxtboxEmail";
            RegtxtboxEmail.PlaceholderText = "";
            RegtxtboxEmail.SelectedText = "";
            RegtxtboxEmail.ShadowDecoration.CustomizableEdges = customizableEdges6;
            RegtxtboxEmail.Size = new Size(286, 31);
            RegtxtboxEmail.TabIndex = 16;
            RegtxtboxEmail.TextChanged += guna2TextBox4_TextChanged;
            // 
            // Emailregtxt
            // 
            Emailregtxt.AutoSize = true;
            Emailregtxt.BackColor = Color.Transparent;
            Emailregtxt.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Emailregtxt.ForeColor = Color.FromArgb(34, 12, 12, 1);
            Emailregtxt.Location = new Point(133, 205);
            Emailregtxt.Name = "Emailregtxt";
            Emailregtxt.Size = new Size(58, 23);
            Emailregtxt.TabIndex = 15;
            Emailregtxt.Text = "Email";
            Emailregtxt.Click += label6_Click;
            // 
            // RegtxtboxFullname
            // 
            RegtxtboxFullname.BorderRadius = 5;
            RegtxtboxFullname.CustomizableEdges = customizableEdges7;
            RegtxtboxFullname.DefaultText = "";
            RegtxtboxFullname.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            RegtxtboxFullname.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            RegtxtboxFullname.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            RegtxtboxFullname.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            RegtxtboxFullname.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            RegtxtboxFullname.Font = new Font("Segoe UI", 9F);
            RegtxtboxFullname.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            RegtxtboxFullname.Location = new Point(24, 163);
            RegtxtboxFullname.Margin = new Padding(3, 4, 3, 4);
            RegtxtboxFullname.Name = "RegtxtboxFullname";
            RegtxtboxFullname.PlaceholderText = "";
            RegtxtboxFullname.SelectedText = "";
            RegtxtboxFullname.ShadowDecoration.CustomizableEdges = customizableEdges8;
            RegtxtboxFullname.Size = new Size(286, 31);
            RegtxtboxFullname.TabIndex = 14;
            // 
            // Fullnameregtxt
            // 
            Fullnameregtxt.AutoSize = true;
            Fullnameregtxt.BackColor = Color.Transparent;
            Fullnameregtxt.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Fullnameregtxt.ForeColor = Color.FromArgb(34, 12, 12, 1);
            Fullnameregtxt.Location = new Point(120, 136);
            Fullnameregtxt.Name = "Fullnameregtxt";
            Fullnameregtxt.Size = new Size(95, 23);
            Fullnameregtxt.TabIndex = 13;
            Fullnameregtxt.Text = "Full Name";
            Fullnameregtxt.Click += label5_Click;
            // 
            // RegtxtboxPassword
            // 
            RegtxtboxPassword.BorderRadius = 5;
            RegtxtboxPassword.CustomizableEdges = customizableEdges9;
            RegtxtboxPassword.DefaultText = "";
            RegtxtboxPassword.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            RegtxtboxPassword.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            RegtxtboxPassword.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            RegtxtboxPassword.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            RegtxtboxPassword.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            RegtxtboxPassword.Font = new Font("Segoe UI", 9F);
            RegtxtboxPassword.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            RegtxtboxPassword.Location = new Point(24, 93);
            RegtxtboxPassword.Margin = new Padding(3, 4, 3, 4);
            RegtxtboxPassword.Name = "RegtxtboxPassword";
            RegtxtboxPassword.PlaceholderText = "";
            RegtxtboxPassword.SelectedText = "";
            RegtxtboxPassword.ShadowDecoration.CustomizableEdges = customizableEdges10;
            RegtxtboxPassword.Size = new Size(286, 31);
            RegtxtboxPassword.TabIndex = 12;
            RegtxtboxPassword.TextChanged += guna2TextBox2_TextChanged;
            // 
            // RegtxtboxUsername
            // 
            RegtxtboxUsername.BorderRadius = 5;
            RegtxtboxUsername.CustomizableEdges = customizableEdges11;
            RegtxtboxUsername.DefaultText = "";
            RegtxtboxUsername.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            RegtxtboxUsername.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            RegtxtboxUsername.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            RegtxtboxUsername.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            RegtxtboxUsername.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            RegtxtboxUsername.Font = new Font("Segoe UI", 9F);
            RegtxtboxUsername.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            RegtxtboxUsername.Location = new Point(24, 27);
            RegtxtboxUsername.Margin = new Padding(3, 4, 3, 4);
            RegtxtboxUsername.Name = "RegtxtboxUsername";
            RegtxtboxUsername.PlaceholderText = "";
            RegtxtboxUsername.SelectedText = "";
            RegtxtboxUsername.ShadowDecoration.CustomizableEdges = customizableEdges12;
            RegtxtboxUsername.Size = new Size(286, 31);
            RegtxtboxUsername.TabIndex = 11;
            RegtxtboxUsername.TextChanged += guna2TextBox1_TextChanged;
            // 
            // Passwordregtxt
            // 
            Passwordregtxt.AutoSize = true;
            Passwordregtxt.BackColor = Color.Transparent;
            Passwordregtxt.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Passwordregtxt.ForeColor = Color.FromArgb(34, 12, 12, 1);
            Passwordregtxt.Location = new Point(116, 66);
            Passwordregtxt.Name = "Passwordregtxt";
            Passwordregtxt.Size = new Size(90, 23);
            Passwordregtxt.TabIndex = 10;
            Passwordregtxt.Text = "Password";
            // 
            // Usernameregtxt
            // 
            Usernameregtxt.AutoSize = true;
            Usernameregtxt.BackColor = Color.Transparent;
            Usernameregtxt.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Usernameregtxt.ForeColor = Color.FromArgb(34, 12, 12, 1);
            Usernameregtxt.Location = new Point(116, 0);
            Usernameregtxt.Name = "Usernameregtxt";
            Usernameregtxt.Size = new Size(95, 23);
            Usernameregtxt.TabIndex = 9;
            Usernameregtxt.Text = "Username";
            Usernameregtxt.Click += Usernameregtxt_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(521, 313);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // Hotelpicpanel
            // 
            Hotelpicpanel.Controls.Add(pictureBox1);
            Hotelpicpanel.Location = new Point(12, 145);
            Hotelpicpanel.Name = "Hotelpicpanel";
            Hotelpicpanel.Size = new Size(521, 313);
            Hotelpicpanel.TabIndex = 7;
            // 
            // Navbarpanel
            // 
            Navbarpanel.BorderStyle = BorderStyle.FixedSingle;
            Navbarpanel.Controls.Add(RegLoginbtn);
            Navbarpanel.Dock = DockStyle.Top;
            Navbarpanel.Location = new Point(0, 0);
            Navbarpanel.Name = "Navbarpanel";
            Navbarpanel.Size = new Size(911, 78);
            Navbarpanel.TabIndex = 6;
            // 
            // RegLoginbtn
            // 
            RegLoginbtn.BackColor = Color.Transparent;
            RegLoginbtn.FlatAppearance.BorderSize = 0;
            RegLoginbtn.FlatStyle = FlatStyle.Flat;
            RegLoginbtn.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            RegLoginbtn.ForeColor = Color.Black;
            RegLoginbtn.Location = new Point(826, 11);
            RegLoginbtn.Name = "RegLoginbtn";
            RegLoginbtn.Size = new Size(72, 57);
            RegLoginbtn.TabIndex = 20;
            RegLoginbtn.Text = "Log in";
            RegLoginbtn.UseVisualStyleBackColor = false;
            RegLoginbtn.Click += RegLoginbtn_Click;
            // 
            // Logo
            // 
            Logo.Dock = DockStyle.Fill;
            Logo.Image = (Image)resources.GetObject("Logo.Image");
            Logo.Location = new Point(0, 0);
            Logo.Name = "Logo";
            Logo.Size = new Size(141, 139);
            Logo.SizeMode = PictureBoxSizeMode.StretchImage;
            Logo.TabIndex = 2;
            Logo.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(Logo);
            panel1.Location = new Point(36, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(141, 139);
            panel1.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ActiveCaption;
            label4.Font = new Font("Georgia", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label4.Location = new Point(551, 112);
            label4.Name = "label4";
            label4.Size = new Size(142, 27);
            label4.TabIndex = 8;
            label4.Text = "REGISTER";
            // 
            // Registration
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(911, 777);
            Controls.Add(label3);
            Controls.Add(TextHolderPanel);
            Controls.Add(RegPanel);
            Controls.Add(label4);
            Controls.Add(Hotelpicpanel);
            Controls.Add(panel1);
            Controls.Add(Navbarpanel);
            Name = "Registration";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Registration";
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            TextHolderPanel.ResumeLayout(false);
            TextHolderPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            RegPanel.ResumeLayout(false);
            RegPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            Hotelpicpanel.ResumeLayout(false);
            Navbarpanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)Logo).EndInit();
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label3;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private Label label2;
        private Label label1;
        private Panel TextHolderPanel;
        private Panel RegPanel;
        private PictureBox pictureBox1;
        private Panel Hotelpicpanel;
        private Panel Navbarpanel;
        private PictureBox Logo;
        private Panel panel1;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private Guna.UI2.WinForms.Guna2TextBox RegtxtboxUsername;
        private Label Passwordregtxt;
        private Label Usernameregtxt;
        private Label label4;
        private Guna.UI2.WinForms.Guna2TextBox RegtxtboxEmail;
        private Label Emailregtxt;
        private Guna.UI2.WinForms.Guna2TextBox RegtxtboxFullname;
        private Label Fullnameregtxt;
        private Guna.UI2.WinForms.Guna2TextBox RegtxtboxPassword;
        private Guna.UI2.WinForms.Guna2TextBox RegtextboxCpno;
        private Label RegContactnumbertxt;
        private Guna.UI2.WinForms.Guna2Button RegBtn;
        private Button RegLoginbtn;
    }
}