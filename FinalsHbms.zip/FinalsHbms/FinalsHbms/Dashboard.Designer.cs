﻿namespace FinalsHbms
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            Navbarpanel = new Panel();
            button1 = new Button();
            label3 = new Label();
            panel2 = new Panel();
            panel4 = new Panel();
            label1 = new Label();
            panel5 = new Panel();
            BunkerBed1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            panel6 = new Panel();
            BunkerBed2 = new PictureBox();
            panel7 = new Panel();
            BunkerBed3 = new PictureBox();
            panel8 = new Panel();
            LargeRooms = new PictureBox();
            panel9 = new Panel();
            DoubleBed = new PictureBox();
            panel10 = new Panel();
            SingleBed = new PictureBox();
            label2 = new Label();
            BunkerBedTourist = new Label();
            label5 = new Label();
            label4 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            EconomyClassbtn = new Button();
            TouristClassbtn = new Button();
            BusinessSuitiebtn = new Button();
            FamilySizebtn = new Button();
            DoubleBedbtn = new Button();
            SingleBedbtn = new Button();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            ServicesPanel = new Panel();
            label16 = new Label();
            panel14 = new Panel();
            pictureBox9 = new PictureBox();
            panel15 = new Panel();
            pictureBox8 = new PictureBox();
            panel13 = new Panel();
            pictureBox6 = new PictureBox();
            panel16 = new Panel();
            pictureBox7 = new PictureBox();
            panel12 = new Panel();
            pictureBox5 = new PictureBox();
            panel11 = new Panel();
            pictureBox4 = new PictureBox();
            panel3 = new Panel();
            panel1 = new Panel();
            Logo = new PictureBox();
            label17 = new Label();
            Navbarpanel.SuspendLayout();
            panel2.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)BunkerBed1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)BunkerBed2).BeginInit();
            panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)BunkerBed3).BeginInit();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)LargeRooms).BeginInit();
            panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DoubleBed).BeginInit();
            panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)SingleBed).BeginInit();
            ServicesPanel.SuspendLayout();
            panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panel3.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Logo).BeginInit();
            SuspendLayout();
            // 
            // Navbarpanel
            // 
            Navbarpanel.BorderStyle = BorderStyle.FixedSingle;
            Navbarpanel.Controls.Add(button1);
            Navbarpanel.Dock = DockStyle.Top;
            Navbarpanel.Location = new Point(0, 0);
            Navbarpanel.Name = "Navbarpanel";
            Navbarpanel.Size = new Size(911, 78);
            Navbarpanel.TabIndex = 12;
            // 
            // button1
            // 
            button1.BackColor = Color.Aqua;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ControlText;
            button1.Location = new Point(766, 20);
            button1.Name = "button1";
            button1.Size = new Size(132, 33);
            button1.TabIndex = 31;
            button1.Text = "NEXT - >";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(255, 129, 0);
            label3.Location = new Point(183, 66);
            label3.Name = "label3";
            label3.Size = new Size(188, 26);
            label3.TabIndex = 15;
            label3.Text = "LUXURY HOTEL";
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(panel4);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(0, 75);
            panel2.Name = "panel2";
            panel2.Size = new Size(911, 34);
            panel2.TabIndex = 16;
            // 
            // panel4
            // 
            panel4.Location = new Point(-1, 48);
            panel4.Name = "panel4";
            panel4.Size = new Size(911, 655);
            panel4.TabIndex = 17;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label1.Location = new Point(444, 5);
            label1.Name = "label1";
            label1.Size = new Size(299, 24);
            label1.TabIndex = 17;
            label1.Text = "TOP NOTCH 5 STAR HOTEL";
            // 
            // panel5
            // 
            panel5.Controls.Add(BunkerBed1);
            panel5.Controls.Add(pictureBox2);
            panel5.Controls.Add(pictureBox1);
            panel5.Location = new Point(36, 172);
            panel5.Name = "panel5";
            panel5.Size = new Size(229, 157);
            panel5.TabIndex = 17;
            // 
            // BunkerBed1
            // 
            BunkerBed1.Dock = DockStyle.Fill;
            BunkerBed1.Image = (Image)resources.GetObject("BunkerBed1.Image");
            BunkerBed1.Location = new Point(0, 0);
            BunkerBed1.Name = "BunkerBed1";
            BunkerBed1.Size = new Size(229, 157);
            BunkerBed1.SizeMode = PictureBoxSizeMode.StretchImage;
            BunkerBed1.TabIndex = 2;
            BunkerBed1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Dock = DockStyle.Fill;
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(229, 157);
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(229, 157);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel6
            // 
            panel6.Controls.Add(BunkerBed2);
            panel6.Location = new Point(336, 172);
            panel6.Name = "panel6";
            panel6.Size = new Size(229, 157);
            panel6.TabIndex = 18;
            // 
            // BunkerBed2
            // 
            BunkerBed2.Dock = DockStyle.Fill;
            BunkerBed2.Image = (Image)resources.GetObject("BunkerBed2.Image");
            BunkerBed2.Location = new Point(0, 0);
            BunkerBed2.Name = "BunkerBed2";
            BunkerBed2.Size = new Size(229, 157);
            BunkerBed2.SizeMode = PictureBoxSizeMode.StretchImage;
            BunkerBed2.TabIndex = 0;
            BunkerBed2.TabStop = false;
            // 
            // panel7
            // 
            panel7.Controls.Add(BunkerBed3);
            panel7.Location = new Point(648, 172);
            panel7.Name = "panel7";
            panel7.Size = new Size(229, 157);
            panel7.TabIndex = 18;
            // 
            // BunkerBed3
            // 
            BunkerBed3.Dock = DockStyle.Fill;
            BunkerBed3.Image = (Image)resources.GetObject("BunkerBed3.Image");
            BunkerBed3.Location = new Point(0, 0);
            BunkerBed3.Name = "BunkerBed3";
            BunkerBed3.Size = new Size(229, 157);
            BunkerBed3.SizeMode = PictureBoxSizeMode.StretchImage;
            BunkerBed3.TabIndex = 0;
            BunkerBed3.TabStop = false;
            // 
            // panel8
            // 
            panel8.Controls.Add(LargeRooms);
            panel8.Location = new Point(36, 520);
            panel8.Name = "panel8";
            panel8.Size = new Size(229, 157);
            panel8.TabIndex = 18;
            // 
            // LargeRooms
            // 
            LargeRooms.Dock = DockStyle.Fill;
            LargeRooms.Image = (Image)resources.GetObject("LargeRooms.Image");
            LargeRooms.Location = new Point(0, 0);
            LargeRooms.Name = "LargeRooms";
            LargeRooms.Size = new Size(229, 157);
            LargeRooms.SizeMode = PictureBoxSizeMode.StretchImage;
            LargeRooms.TabIndex = 0;
            LargeRooms.TabStop = false;
            // 
            // panel9
            // 
            panel9.Controls.Add(DoubleBed);
            panel9.Location = new Point(336, 520);
            panel9.Name = "panel9";
            panel9.Size = new Size(229, 157);
            panel9.TabIndex = 18;
            // 
            // DoubleBed
            // 
            DoubleBed.Dock = DockStyle.Fill;
            DoubleBed.Image = (Image)resources.GetObject("DoubleBed.Image");
            DoubleBed.Location = new Point(0, 0);
            DoubleBed.Name = "DoubleBed";
            DoubleBed.Size = new Size(229, 157);
            DoubleBed.SizeMode = PictureBoxSizeMode.StretchImage;
            DoubleBed.TabIndex = 0;
            DoubleBed.TabStop = false;
            // 
            // panel10
            // 
            panel10.Controls.Add(SingleBed);
            panel10.Location = new Point(648, 520);
            panel10.Name = "panel10";
            panel10.Size = new Size(229, 157);
            panel10.TabIndex = 18;
            // 
            // SingleBed
            // 
            SingleBed.Dock = DockStyle.Fill;
            SingleBed.Image = (Image)resources.GetObject("SingleBed.Image");
            SingleBed.Location = new Point(0, 0);
            SingleBed.Name = "SingleBed";
            SingleBed.Size = new Size(229, 157);
            SingleBed.SizeMode = PictureBoxSizeMode.StretchImage;
            SingleBed.TabIndex = 0;
            SingleBed.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label2.Location = new Point(81, 342);
            label2.Name = "label2";
            label2.Size = new Size(143, 20);
            label2.TabIndex = 18;
            label2.Text = "Economy Class";
            label2.Click += label2_Click;
            // 
            // BunkerBedTourist
            // 
            BunkerBedTourist.AutoSize = true;
            BunkerBedTourist.BackColor = Color.Transparent;
            BunkerBedTourist.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BunkerBedTourist.ForeColor = Color.FromArgb(34, 12, 12, 1);
            BunkerBedTourist.Location = new Point(389, 342);
            BunkerBedTourist.Name = "BunkerBedTourist";
            BunkerBedTourist.Size = new Size(127, 20);
            BunkerBedTourist.TabIndex = 19;
            BunkerBedTourist.Text = "Tourist Class";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label5.Location = new Point(697, 342);
            label5.Name = "label5";
            label5.Size = new Size(142, 20);
            label5.TabIndex = 20;
            label5.Text = "Bussines Suite";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label4.Location = new Point(336, 136);
            label4.Name = "label4";
            label4.Size = new Size(229, 24);
            label4.TabIndex = 18;
            label4.Text = "BED BUNK CHOICES";
            label4.Click += label4_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label6.Location = new Point(389, 483);
            label6.Name = "label6";
            label6.Size = new Size(124, 24);
            label6.TabIndex = 21;
            label6.Text = "BEDROOM";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label7.Location = new Point(713, 689);
            label7.Name = "label7";
            label7.Size = new Size(104, 20);
            label7.TabIndex = 22;
            label7.Text = "Single Bed";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label8.Location = new Point(81, 689);
            label8.Name = "label8";
            label8.Size = new Size(110, 20);
            label8.TabIndex = 23;
            label8.Text = "Family Size";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label9.Location = new Point(392, 689);
            label9.Name = "label9";
            label9.Size = new Size(114, 20);
            label9.TabIndex = 24;
            label9.Text = "Double Bed";
            // 
            // EconomyClassbtn
            // 
            EconomyClassbtn.BackColor = Color.Aqua;
            EconomyClassbtn.FlatAppearance.BorderSize = 0;
            EconomyClassbtn.FlatStyle = FlatStyle.Flat;
            EconomyClassbtn.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            EconomyClassbtn.ForeColor = SystemColors.ControlText;
            EconomyClassbtn.Location = new Point(57, 423);
            EconomyClassbtn.Name = "EconomyClassbtn";
            EconomyClassbtn.Size = new Size(188, 39);
            EconomyClassbtn.TabIndex = 25;
            EconomyClassbtn.Text = "BOOK NOW";
            EconomyClassbtn.UseVisualStyleBackColor = false;
            // 
            // TouristClassbtn
            // 
            TouristClassbtn.BackColor = Color.Aqua;
            TouristClassbtn.FlatAppearance.BorderSize = 0;
            TouristClassbtn.FlatStyle = FlatStyle.Flat;
            TouristClassbtn.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TouristClassbtn.ForeColor = SystemColors.ControlText;
            TouristClassbtn.Location = new Point(360, 423);
            TouristClassbtn.Name = "TouristClassbtn";
            TouristClassbtn.Size = new Size(188, 39);
            TouristClassbtn.TabIndex = 26;
            TouristClassbtn.Text = "BOOK NOW";
            TouristClassbtn.UseVisualStyleBackColor = false;
            // 
            // BusinessSuitiebtn
            // 
            BusinessSuitiebtn.BackColor = Color.Aqua;
            BusinessSuitiebtn.FlatAppearance.BorderSize = 0;
            BusinessSuitiebtn.FlatStyle = FlatStyle.Flat;
            BusinessSuitiebtn.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BusinessSuitiebtn.ForeColor = SystemColors.ControlText;
            BusinessSuitiebtn.Location = new Point(665, 423);
            BusinessSuitiebtn.Name = "BusinessSuitiebtn";
            BusinessSuitiebtn.Size = new Size(188, 39);
            BusinessSuitiebtn.TabIndex = 27;
            BusinessSuitiebtn.Text = "BOOK NOW";
            BusinessSuitiebtn.UseVisualStyleBackColor = false;
            // 
            // FamilySizebtn
            // 
            FamilySizebtn.BackColor = Color.Aqua;
            FamilySizebtn.FlatAppearance.BorderSize = 0;
            FamilySizebtn.FlatStyle = FlatStyle.Flat;
            FamilySizebtn.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            FamilySizebtn.ForeColor = SystemColors.ControlText;
            FamilySizebtn.Location = new Point(57, 764);
            FamilySizebtn.Name = "FamilySizebtn";
            FamilySizebtn.Size = new Size(188, 39);
            FamilySizebtn.TabIndex = 28;
            FamilySizebtn.Text = "BOOK NOW";
            FamilySizebtn.UseVisualStyleBackColor = false;
            // 
            // DoubleBedbtn
            // 
            DoubleBedbtn.BackColor = Color.Aqua;
            DoubleBedbtn.FlatAppearance.BorderSize = 0;
            DoubleBedbtn.FlatStyle = FlatStyle.Flat;
            DoubleBedbtn.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DoubleBedbtn.ForeColor = SystemColors.ControlText;
            DoubleBedbtn.Location = new Point(360, 764);
            DoubleBedbtn.Name = "DoubleBedbtn";
            DoubleBedbtn.Size = new Size(188, 39);
            DoubleBedbtn.TabIndex = 29;
            DoubleBedbtn.Text = "BOOK NOW";
            DoubleBedbtn.UseVisualStyleBackColor = false;
            // 
            // SingleBedbtn
            // 
            SingleBedbtn.BackColor = Color.Aqua;
            SingleBedbtn.FlatAppearance.BorderSize = 0;
            SingleBedbtn.FlatStyle = FlatStyle.Flat;
            SingleBedbtn.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SingleBedbtn.ForeColor = SystemColors.ControlText;
            SingleBedbtn.Location = new Point(665, 764);
            SingleBedbtn.Name = "SingleBedbtn";
            SingleBedbtn.Size = new Size(188, 39);
            SingleBedbtn.TabIndex = 30;
            SingleBedbtn.Text = "BOOK NOW";
            SingleBedbtn.UseVisualStyleBackColor = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label10.Location = new Point(93, 380);
            label10.Name = "label10";
            label10.Size = new Size(91, 24);
            label10.TabIndex = 31;
            label10.Text = "₱ 2, 500";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label11.Location = new Point(415, 380);
            label11.Name = "label11";
            label11.Size = new Size(90, 24);
            label11.TabIndex = 32;
            label11.Text = "₱ 3, 500";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label12.Location = new Point(726, 380);
            label12.Name = "label12";
            label12.Size = new Size(91, 24);
            label12.TabIndex = 33;
            label12.Text = "₱ 4, 500";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label13.Location = new Point(93, 724);
            label13.Name = "label13";
            label13.Size = new Size(91, 24);
            label13.TabIndex = 34;
            label13.Text = "₱ 6, 500";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.Transparent;
            label14.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label14.Location = new Point(415, 724);
            label14.Name = "label14";
            label14.Size = new Size(88, 24);
            label14.TabIndex = 35;
            label14.Text = "₱ 4,000";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = Color.Transparent;
            label15.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label15.Location = new Point(726, 724);
            label15.Name = "label15";
            label15.Size = new Size(65, 24);
            label15.TabIndex = 36;
            label15.Text = "₱ 700";
            // 
            // ServicesPanel
            // 
            ServicesPanel.Controls.Add(panel14);
            ServicesPanel.Controls.Add(panel15);
            ServicesPanel.Controls.Add(panel13);
            ServicesPanel.Controls.Add(panel16);
            ServicesPanel.Controls.Add(panel12);
            ServicesPanel.Controls.Add(panel11);
            ServicesPanel.Controls.Add(panel3);
            ServicesPanel.Location = new Point(0, 108);
            ServicesPanel.Name = "ServicesPanel";
            ServicesPanel.Size = new Size(911, 705);
            ServicesPanel.TabIndex = 37;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = Color.Transparent;
            label16.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label16.Location = new Point(363, 7);
            label16.Name = "label16";
            label16.Size = new Size(185, 24);
            label16.TabIndex = 18;
            label16.Text = "FOOD SERVICES";
            // 
            // panel14
            // 
            panel14.Controls.Add(pictureBox9);
            panel14.Location = new Point(655, 375);
            panel14.Name = "panel14";
            panel14.Size = new Size(256, 180);
            panel14.TabIndex = 4;
            // 
            // pictureBox9
            // 
            pictureBox9.Dock = DockStyle.Fill;
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(0, 0);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(256, 180);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 0;
            pictureBox9.TabStop = false;
            // 
            // panel15
            // 
            panel15.Controls.Add(pictureBox8);
            panel15.Location = new Point(326, 375);
            panel15.Name = "panel15";
            panel15.Size = new Size(256, 180);
            panel15.TabIndex = 3;
            // 
            // pictureBox8
            // 
            pictureBox8.Dock = DockStyle.Fill;
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(0, 0);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(256, 180);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 0;
            pictureBox8.TabStop = false;
            // 
            // panel13
            // 
            panel13.BackColor = Color.Transparent;
            panel13.Controls.Add(pictureBox6);
            panel13.Location = new Point(655, 51);
            panel13.Name = "panel13";
            panel13.Size = new Size(256, 180);
            panel13.TabIndex = 1;
            // 
            // pictureBox6
            // 
            pictureBox6.Dock = DockStyle.Fill;
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(0, 0);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(256, 180);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 0;
            pictureBox6.TabStop = false;
            // 
            // panel16
            // 
            panel16.Controls.Add(pictureBox7);
            panel16.Location = new Point(0, 375);
            panel16.Name = "panel16";
            panel16.Size = new Size(256, 180);
            panel16.TabIndex = 2;
            // 
            // pictureBox7
            // 
            pictureBox7.Dock = DockStyle.Fill;
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(0, 0);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(256, 180);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 5;
            pictureBox7.TabStop = false;
            // 
            // panel12
            // 
            panel12.BackColor = Color.Transparent;
            panel12.Controls.Add(pictureBox5);
            panel12.Location = new Point(326, 51);
            panel12.Name = "panel12";
            panel12.Size = new Size(256, 180);
            panel12.TabIndex = 1;
            // 
            // pictureBox5
            // 
            pictureBox5.Dock = DockStyle.Fill;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(0, 0);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(256, 180);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 0;
            pictureBox5.TabStop = false;
            // 
            // panel11
            // 
            panel11.BackColor = Color.Transparent;
            panel11.Controls.Add(pictureBox4);
            panel11.Location = new Point(0, 51);
            panel11.Name = "panel11";
            panel11.Size = new Size(256, 180);
            panel11.TabIndex = 0;
            // 
            // pictureBox4
            // 
            pictureBox4.Dock = DockStyle.Fill;
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(0, 0);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(256, 180);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 1;
            pictureBox4.TabStop = false;
            // 
            // panel3
            // 
            panel3.Controls.Add(label17);
            panel3.Controls.Add(label16);
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(911, 705);
            panel3.TabIndex = 19;
            // 
            // panel1
            // 
            panel1.Controls.Add(Logo);
            panel1.Location = new Point(36, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(141, 139);
            panel1.TabIndex = 11;
            // 
            // Logo
            // 
            Logo.Dock = DockStyle.Fill;
            Logo.Image = (Image)resources.GetObject("Logo.Image");
            Logo.Location = new Point(0, 0);
            Logo.Name = "Logo";
            Logo.Size = new Size(141, 139);
            Logo.SizeMode = PictureBoxSizeMode.StretchImage;
            Logo.TabIndex = 4;
            Logo.TabStop = false;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.Transparent;
            label17.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.ForeColor = Color.FromArgb(34, 12, 12, 1);
            label17.Location = new Point(366, 330);
            label17.Name = "label17";
            label17.Size = new Size(199, 24);
            label17.TabIndex = 19;
            label17.Text = "HOTEL SERVICES";
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(911, 811);
            Controls.Add(panel1);
            Controls.Add(ServicesPanel);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(SingleBedbtn);
            Controls.Add(DoubleBedbtn);
            Controls.Add(FamilySizebtn);
            Controls.Add(BusinessSuitiebtn);
            Controls.Add(TouristClassbtn);
            Controls.Add(EconomyClassbtn);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(BunkerBedTourist);
            Controls.Add(label2);
            Controls.Add(panel10);
            Controls.Add(panel9);
            Controls.Add(panel8);
            Controls.Add(panel7);
            Controls.Add(panel6);
            Controls.Add(panel5);
            Controls.Add(label3);
            Controls.Add(Navbarpanel);
            Controls.Add(panel2);
            Name = "Dashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Dashboard";
            Load += Dashboard_Load;
            Navbarpanel.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)BunkerBed1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)BunkerBed2).EndInit();
            panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)BunkerBed3).EndInit();
            panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)LargeRooms).EndInit();
            panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)DoubleBed).EndInit();
            panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)SingleBed).EndInit();
            ServicesPanel.ResumeLayout(false);
            panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            panel15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            panel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            panel16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)Logo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel Navbarpanel;
        private Label label3;
        private Panel panel2;
        private Label label1;
        private Panel panel4;
        private Panel panel5;
        private PictureBox BunkerBed1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Panel panel6;
        private Panel panel7;
        private Panel panel8;
        private Panel panel9;
        private Panel panel10;
        private PictureBox BunkerBed2;
        private PictureBox BunkerBed3;
        private PictureBox LargeRooms;
        private PictureBox DoubleBed;
        private PictureBox SingleBed;
        private Label label2;
        private Label BunkerBedTourist;
        private Label label5;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Button EconomyClassbtn;
        private Button TouristClassbtn;
        private Button BusinessSuitiebtn;
        private Button FamilySizebtn;
        private Button DoubleBedbtn;
        private Button SingleBedbtn;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Button button1;
        private Panel ServicesPanel;
        private Panel panel11;
        private Label label16;
        private Panel panel14;
        private PictureBox pictureBox9;
        private Panel panel15;
        private PictureBox pictureBox8;
        private Panel panel13;
        private PictureBox pictureBox6;
        private Panel panel16;
        private PictureBox pictureBox7;
        private Panel panel12;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private Panel panel1;
        private PictureBox Logo;
        private Panel panel3;
        private Label label17;
    }
}